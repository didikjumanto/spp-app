<?php

namespace App\Controllers;

class Auth extends BaseController
{
    public function index()
    {
        $data = [
            "title" => "SPP Sekolah -  Login",
            "validation" => \config\services::validation()
        ];
        return view('login',$data);
    }

    public function authentication()
    {
        if(!$this->validate([
            "username" => "required|alpha_numeric|max_length[6]",
            "password" => "required|alpha_numeric|max_length[30]"

        ])){

            $validation = \config\services::validation();
            return redirect()->to("auth")->withInput()->with("validation",$validation);
        }

        return redirect()-> to("home");
    }
}
